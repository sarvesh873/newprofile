import React, { useContext, useState, useEffect } from "react";
import { UserContext } from "./UserContext";
import { makeStyles } from "@material-ui/core/styles";
import { TextField, Grid, Button } from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  summary: {
    padding: theme.spacing(3),
    border: "1px solid #ddd",
    marginBottom: theme.spacing(2)
  },
  buttonContainer: {
    marginTop: theme.spacing(2),
    textAlign: 'center'
  }
}));

const Summary = () => {
  const classes = useStyles();
  const [state, dispatch] = useContext(UserContext);
  const [depMem, setDepMem] = useState('');
  const [currentDepIndex, setCurrentDepIndex] = useState(0);
  const [depDetails, setDepDetails] = useState([]);
  const { user } = state;

  useEffect(() => {
    const storedDepMem = localStorage.getItem('depMem');
    if (storedDepMem !== null && !user.depMem) {
      console.log("idhae")
      setDepMem(parseInt(storedDepMem));
    }
    
     const storedDepDetails = localStorage.getItem('depDetails');
     if (storedDepDetails && !user.depDetails) {
       console.log("udhae")
       setDepDetails(JSON.parse(storedDepDetails));
     }
  }, []);

  const handleDepMemChange = (e) => {
    const parsedValue = parseInt(e.target.value, 10);
    if (!isNaN(parsedValue)) {
      setDepMem(parsedValue);
      setDepDetails(Array(parsedValue).fill({ name: '', age: '' }));
      dispatch({ type: 'UPDATE_USER', payload: { ...user, depMem: parsedValue, depDetails: Array(parsedValue).fill({ name: '', age: '' }) } });
    } else {
      console.log("Enter a valid number");
    }
  };

  const handleInputChange = (index, field, value) => {
    setDepDetails(prevDetails => {
      const updatedDetails = [...prevDetails];
      updatedDetails[index] = {
        ...updatedDetails[index],
        [field]: value
      };
      return updatedDetails;
    });
  };

  useEffect(() => {
    localStorage.setItem('depDetails', JSON.stringify(depDetails));
    localStorage.setItem('depMem', depMem);
  }, [depDetails, depMem]);

  const handleNext = () => {
    setCurrentDepIndex(prevIndex => prevIndex + 1);
  };

  const handlePrevious = () => {
    setCurrentDepIndex(prevIndex => prevIndex - 1);
  };

  return (
    <Grid container spacing={2}>
      <Grid item xs={12}>
        <TextField
          id='noOfDependentMembers'
          label='Number of Dependent Members'
          name='noOfDependentMembers'
          type='number'
          value={depMem}
          onChange={handleDepMemChange}
          variant='outlined'
          margin='normal'
          InputLabelProps={{
            shrink: true
          }}
          required
          fullWidth
        />
      </Grid>
      {depDetails.map((dep, index) => (
        <div key={index} style={{ display: index === currentDepIndex ? 'block' : 'none' }}>
          <Grid item xs={12}>
            <TextField
              id={`dependentName${index}`}
              label='Name'
              name={`dependentName${index}`}
              value={dep.name}
              onChange={(e) => handleInputChange(index, 'name', e.target.value)}
              required
              variant='outlined'
              margin='normal'
              fullWidth
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              id={`dependentAge${index}`}
              label='Age'
              name={`dependentAge${index}`}
              type='number'
              value={dep.age}
              onChange={(e) => handleInputChange(index, 'age', e.target.value)}
              required
              variant='outlined'
              margin='normal'
              fullWidth
            />
          </Grid>
        </div>
      ))}
      <Grid item xs={12} className={classes.buttonContainer}>
        {currentDepIndex > 0 && (
          <Button variant="contained" color="primary" onClick={handlePrevious}>
            Previous
          </Button>
        )}
        {currentDepIndex < depMem - 1 && (
          <Button variant="contained" color="primary" onClick={handleNext}>
            Next
          </Button>
        )}
      </Grid>
    </Grid>
  );
};

export default Summary;
